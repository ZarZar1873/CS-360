package com.zybooks.drury_5_2_coding_in_andriod_studio;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText name; // Edit text box for user inputted name
    private TextView greeting; // Text box for greeting or default instructions
    private Button helloBtn; // Button for displaying hello message

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // finds view for edit text box
        name = findViewById(R.id.nameText);
        // Adds text change listener to check if name text box was altered
        name.addTextChangedListener(checkName);
        // finds view for greeting text box
        greeting = findViewById(R.id.textGreeting);
        // finds view for hello button
        helloBtn = findViewById(R.id.buttonSayHello);

    }

    /*
    TextWatcher function checks if the edit text box is altered by the user
     */
    private final TextWatcher checkName = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            // Auto generated function for TextWatcher
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            /*
            Hello Button is disabled if the field is empty and enabled if the
            field is not empty
             */
            helloBtn.setEnabled(!s.toString().equals(""));
        }

        @Override
        public void afterTextChanged(Editable s) {
            // Auto generated function for TextWatcher
        }
    };

    /*
    SayHello function takes a view as a parameter and returned void. It is called when
    the hello button is pressed. (Set in the activity_main.xml
     */
    public void SayHello(View view) {
        // Gets user inputted name from edit text box and turns it into a string
        String enteredName = name.getText().toString();

        // If the entered name is not empty
        if (!enteredName.equals("")) {
            // Creates string that is "Hello name"
            String fullGreeting = getString(R.string.greetingIntro) + " " + enteredName;
            // Displays the full greeting in the text box
            greeting.setText(fullGreeting);
        }
        // If the entered name is empty
        else{
            // Text box displays "You must enter a name"
            greeting.setText(getString(R.string.defaultInstructions));
            /*
            Button is disabled and is only enabled if the user enters a name into the
            edit text box (see TextWatcher)
             */
            helloBtn.setEnabled(false);
        }
    }
}
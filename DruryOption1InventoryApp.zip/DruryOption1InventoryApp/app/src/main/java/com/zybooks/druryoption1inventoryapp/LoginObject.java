package com.zybooks.druryoption1inventoryapp;

public class LoginObject {
    long _id;
    String username;
    String password;


    public LoginObject(long _id, String username, String password) {
        this._id = _id;
        this.username = username;
        this.password = password;
    }

    public LoginObject(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public LoginObject(){

    }

    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "LoginObject{" +
                "_id=" + _id +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}

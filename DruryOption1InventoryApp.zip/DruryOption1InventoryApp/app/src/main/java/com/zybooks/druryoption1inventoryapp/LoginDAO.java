package com.zybooks.druryoption1inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class LoginDAO {

    private SQLiteDatabase db;

    public LoginDAO(SQLiteDatabase db) {
        this.db = db;
    }

    public long create(LoginObject loginObject){
        ContentValues values = new ContentValues();

        values.put(LoginTable.COLUMN_USERNAME, loginObject.getUsername());
        values.put(LoginTable.COLUMN_PASSWORD, loginObject.getPassword());

         return db.insert(LoginTable.TABLE_NAME, null, values);
    }

    public boolean update (LoginObject loginObject){
        ContentValues values = new ContentValues();

        values.put(LoginTable.COLUMN_USERNAME, loginObject.getUsername());
        values.put(LoginTable.COLUMN_PASSWORD, loginObject.getPassword());

        return db.update(LoginTable.TABLE_NAME, values, LoginTable.COLUMN_ID + " = ?",
                new String[]{String.valueOf(loginObject.get_id())}) > 0;
    }

    public boolean delete (LoginObject loginObject){
        return db.delete(LoginTable.TABLE_NAME, LoginTable.COLUMN_ID + " = ?",
                new String[]{String.valueOf(loginObject.get_id())}) > 0;
    }

    public boolean delete (long id){
        return db.delete(LoginTable.TABLE_NAME, LoginTable.COLUMN_ID + " = ?",
                new String[]{String.valueOf(id)}) > 0;
    }

    public LoginObject get(long id){
        LoginObject loginObject = null;

        Cursor cursor = db.query(LoginTable.TABLE_NAME, new String[]{LoginTable.COLUMN_ID,
                        LoginTable.COLUMN_USERNAME, LoginTable.COLUMN_PASSWORD},
                LoginTable.COLUMN_ID + " = ?", new String[]{String.valueOf(id)},
                null, null, null);

        // Returns true if cursor was able to be moved
        if (cursor.moveToFirst()){
            loginObject = buildLoginObjectFromCursor(cursor);
        }

        return loginObject;
    }

    public LoginObject get(String username){
        LoginObject loginObject = null;

        Cursor cursor = db.query(LoginTable.TABLE_NAME, new String[]{LoginTable.COLUMN_ID,
                        LoginTable.COLUMN_USERNAME, LoginTable.COLUMN_PASSWORD},
                LoginTable.COLUMN_USERNAME + " = ?", new String[]{username},
                null, null, null);

        // Returns true if cursor was able to be moved
        if (cursor.moveToFirst()){
            loginObject = buildLoginObjectFromCursor(cursor);
        }

        return loginObject;
    }

    public ArrayList<LoginObject> getAll(){
        ArrayList<LoginObject> loginObjects = new ArrayList<>();

        Cursor cursor = db.query(LoginTable.TABLE_NAME, new String[]{LoginTable.COLUMN_ID,
                        LoginTable.COLUMN_USERNAME, LoginTable.COLUMN_PASSWORD},
                null, null, null, null, null);

        cursor.moveToFirst();

        LoginObject loginObject = buildLoginObjectFromCursor(cursor);
        loginObjects.add(loginObject);

        // Will return false if the cursor is already past the last entry in the result set
        while (cursor.moveToNext()){
            loginObject = buildLoginObjectFromCursor(cursor);
            loginObjects.add(loginObject);
        }

        return loginObjects;
    }

    private LoginObject buildLoginObjectFromCursor (Cursor cursor){
        LoginObject loginObject = new LoginObject();
        loginObject.set_id(cursor.getLong(0));
        loginObject.setUsername(cursor.getString(1));
        loginObject.setPassword(cursor.getString(2));
        return loginObject;
    }
}

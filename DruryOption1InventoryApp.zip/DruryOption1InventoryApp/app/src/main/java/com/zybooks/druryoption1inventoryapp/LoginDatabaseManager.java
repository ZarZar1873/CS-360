package com.zybooks.druryoption1inventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class LoginDatabaseManager {
    Context mContext;
    SQLiteDatabase db;
    LoginDatabaseHelper dbOpenHelper;
    LoginDAO loginDAO;

    public LoginDatabaseManager(Context context) {
        this.mContext = context;
        dbOpenHelper = new LoginDatabaseHelper(mContext);
        db = dbOpenHelper.getWritableDatabase();

        loginDAO = new LoginDAO(db);
    }

    public LoginDAO getLoginDAO() {
        return loginDAO;
    }
}

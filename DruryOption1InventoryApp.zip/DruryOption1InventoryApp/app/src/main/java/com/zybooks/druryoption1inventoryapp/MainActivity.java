package com.zybooks.druryoption1inventoryapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,
        AddNewItem.AddItemListener, ItemRecyclerViewAdapter.InterfaceItemRecycler, SettingsActivity.SettingListener {
    ArrayList<Item> items;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    ItemRecyclerViewAdapter adapter;
    ItemDatabaseManager itemDatabaseManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        itemDatabaseManager = new ItemDatabaseManager(this);

        recyclerView = findViewById(R.id.itemRecyclerView);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        loadRecyclerView();
        findViewById(R.id.addBtn).setOnClickListener(view -> addItemClick());

        ImageButton settings = findViewById(R.id.settingBtn);
        settings.setOnClickListener(this);

        // sets boolean to if the permission for sms is granted
        smsAllowed = ContextCompat.checkSelfPermission(MainActivity.this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    //loads recycler view with current items in the database
    public void loadRecyclerView(){
        items = itemDatabaseManager.getItemDAO().getAll();
        adapter= new ItemRecyclerViewAdapter(items, this);
        recyclerView.setAdapter(adapter);
    }

    // launches add new item fragment
    private void addItemClick() {
        getSupportFragmentManager().beginTransaction().add(R.id.constraintView, new AddNewItem(),
                "addNewItem").commit();
    }

    @Override
    public void onClick(View v) {
        // if the user taps the settings button then launch the settings fragment
        if (v.getId() == R.id.settingBtn) {
            getSupportFragmentManager().beginTransaction().add(R.id.constraintView, new SettingsActivity(),
                    "settings").commit();
        }
    }

    // Removes teh add new item fragment so it no longer appears
    public void removeAddNewItemFragment(){
        Fragment fragment = getSupportFragmentManager().findFragmentByTag("addNewItem");
        if (fragment != null){
            getSupportFragmentManager().beginTransaction().remove(fragment).commit();
        }
    }
    // Adds new item to the database with auto incremented id and given name and quantity
    @Override
    public void sendNewItemInfo(String name, int quantity) {
        itemDatabaseManager.getItemDAO().create(new Item(name, quantity));
        removeAddNewItemFragment();
        loadRecyclerView();
    }

    // Add new item cancel button that removes the fragment
    @Override
    public void cancel() {
        removeAddNewItemFragment();
    }

    // removes item from the database with given name and then reloads the recycler
    @Override
    public void deleteItem(String name) {
        itemDatabaseManager.getItemDAO().delete(itemDatabaseManager.getItemDAO().get(name));
        loadRecyclerView();
    }

    /*
    Updates the item quantity in the database from the given name and quantity from the item recycler
    view adapter
     */
    @Override
    public void updateItemQuantity(String name, int quantity) {
        itemDatabaseManager.getItemDAO().update(itemDatabaseManager.getItemDAO().get(name), name, quantity);
    }

    /*
    Sends message to user if the quantity of an item is less than or equal to 0. Gets name from
    recycler view adapter and phone number from the number entered in the settings fragment.
     */
    @Override
    public void sendSMS(String name) {
        if(smsAllowed && (userPhoneNumber != null)) {
            String phoneNumber = userPhoneNumber;
            String message = "Inventory is out of " + name;
            if (!phoneNumber.isEmpty()) { // ensure the number is not empty
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            }
        }
    }

    // removed the settings fragment
    public void removeSettingsFragment(){
        Fragment fragment = getSupportFragmentManager().findFragmentByTag("settings");
        if (fragment != null){
            getSupportFragmentManager().beginTransaction().remove(fragment).commit();
        }
    }

    // if the cancel button is pressed on the settings fragment, then remove the settings fragment
    @Override
    public void settingsCancel() {
        removeSettingsFragment();
    }


    String userPhoneNumber;
    boolean smsAllowed;
    @Override
    public void settingSave(boolean allowSMS, String phoneNumber) {
        if (allowSMS){
            ActivityCompat.requestPermissions(MainActivity.this,
                    new String[]{Manifest.permission.SEND_SMS}, 100);
            userPhoneNumber = phoneNumber;
            smsAllowed = true;
        }
        else{
            smsAllowed = false;
        }
        removeSettingsFragment();
    }

    @Override
    public boolean checkSMSAllowed() {
        return smsAllowed;
    }

    @Override
    public String getPhoneNumber() {
        return userPhoneNumber;
    }
}
package com.zybooks.druryoption1inventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class ItemDatabaseManager {
    Context mContext;
    SQLiteDatabase db;
    ItemDatabaseHelper dbOpenHelper;
    ItemDAO itemDAO;

    public ItemDatabaseManager(Context context) {
        this.mContext = context;
        dbOpenHelper = new ItemDatabaseHelper(mContext);
        db = dbOpenHelper.getWritableDatabase();

        itemDAO = new ItemDAO(db);
    }

    public ItemDatabaseManager(AddNewItem addNewItem) {

    }

    public ItemDAO getItemDAO() {
        return itemDAO;
    }
}

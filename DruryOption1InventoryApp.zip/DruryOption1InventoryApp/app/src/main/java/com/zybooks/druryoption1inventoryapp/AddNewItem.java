package com.zybooks.druryoption1inventoryapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.zybooks.druryoption1inventoryapp.databinding.FragmentAddNewItemBinding;

public class AddNewItem extends Fragment{

    public AddNewItem() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    FragmentAddNewItemBinding addNewItemBinding; // Binding for addNewItem
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        addNewItemBinding = FragmentAddNewItemBinding.inflate(inflater, container, false);
        // Inflate the layout for this fragment
        return addNewItemBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // set add item warning to invisible
        addNewItemBinding.addItemWarning.setVisibility(View.INVISIBLE);

        /*
          When the user taps the confirm button, if the new item name and the new item quantity
          are not empty, then set the variable name and quantity to the text in the respective edit
          text boxes and then send that information to the main activity to add the new item to the
          item database and update the recyclerview

          else set the add item warning to visible to assist user in adding a new item
         */
        addNewItemBinding.addConfirmBtn.setOnClickListener(v -> {

            if (!(addNewItemBinding.addNewItemName.getText().toString().equals("")) &&
                    !(addNewItemBinding.addNewItemQuantity.getText().toString().equals(""))) {
                String name = addNewItemBinding.addNewItemName.getText().toString();
                int quantity = Integer.parseInt(addNewItemBinding.addNewItemQuantity
                        .getText().toString());

                mListener.sendNewItemInfo(name, quantity);
            }
            else{
                addNewItemBinding.addItemWarning.setVisibility(View.VISIBLE);
            }
        });

        /*
        When the user taps teh cancel button then run the cancel function in the main activity
         */
        addNewItemBinding.addCancelBtn.setOnClickListener(v -> mListener.cancel());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    AddItemListener mListener; // listener for the interface

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (AddItemListener) context; // Sets listener
    }

    // Define the interface for the add item fragment
    public interface AddItemListener{
        void sendNewItemInfo(String name, int quantity);
        void cancel();
    }
}
package com.zybooks.druryoption1inventoryapp;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class LoginTable {
    static final String TABLE_NAME = "login";
    static final String COLUMN_ID = "_id";
    static final String COLUMN_USERNAME = "username";
    static final String COLUMN_PASSWORD = "password";

    static public void onCreate(SQLiteDatabase db){
        StringBuilder sb = new StringBuilder();

        /*
         * Create table login (_id integer primary key autoincrement,
         * username text not null, password text not null)
         */
        sb.append("CREATE TABLE " + LoginTable.TABLE_NAME + " (");
        sb.append(COLUMN_ID + " integer primary key autoincrement, ");
        sb.append(COLUMN_USERNAME + " text not null, ");
        sb.append(COLUMN_PASSWORD + " text not null);");

        try {
            db.execSQL(sb.toString());
        } catch (SQLException ex){
            ex.printStackTrace();
        }
    }

    static public void onUpdate(SQLiteDatabase db, int oldVersion, int newVersion){
        try {
            db.execSQL("DROP TABLE IF EXISTS " + LoginTable.TABLE_NAME);
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
    }
}

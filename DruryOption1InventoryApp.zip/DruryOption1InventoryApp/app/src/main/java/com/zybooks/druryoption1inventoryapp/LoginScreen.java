package com.zybooks.druryoption1inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity implements View.OnClickListener {
    String TAG = "test";
    LoginDatabaseManager loginDatabaseManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loginDatabaseManager = new LoginDatabaseManager(this);

        Button login = findViewById(R.id.loginBtn);
        login.setOnClickListener(this);

        Button newUser = findViewById(R.id.newUserBtn);
        newUser.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        //get variables from text boxes
        TextView invalidInput = findViewById(R.id.invalidInputText);
        String username = ((EditText)findViewById(R.id.username)).getText().toString();
        String password = ((EditText)findViewById(R.id.password)).getText().toString();

        /*
        if the user taps the login button then get the loginObject from the database with the given
        username.
            if the loginObject exists (is not null) and the given password matches the password
            attached to the loginObject, then set the invalid input warning message to invisible
            and start the main activity
            else set the warning message to visible
         */
        if (v.getId() == R.id.loginBtn){
            LoginObject loginObject = loginDatabaseManager.getLoginDAO().get(username);

            if (loginObject != null) {
                if (loginObject.getPassword().equals(password)){
                    invalidInput.setVisibility(View.INVISIBLE);
                    Intent intent = new Intent(LoginScreen.this, MainActivity.class);
                    startActivity(intent);
                }
                else{
                    invalidInput.setVisibility(View.VISIBLE);
                }
            }
            else{
                invalidInput.setVisibility(View.VISIBLE);
            }
        }
        /*
        if the user taps the new user button then create a new login object and add that to the
        database
         */
        else if (v.getId() == R.id.newUserBtn){
            if (!(username.equals("")) && (!(password.equals("")))){
                loginDatabaseManager.getLoginDAO().create(new LoginObject(username, password));
            }
        }

    }
}

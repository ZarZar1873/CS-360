package com.zybooks.druryoption1inventoryapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.zybooks.druryoption1inventoryapp.databinding.FragmentSettingsActivityBinding;

public class SettingsActivity extends Fragment {

    public SettingsActivity() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    FragmentSettingsActivityBinding settingsActivityBinding;
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        settingsActivityBinding = FragmentSettingsActivityBinding.inflate(inflater, container, false);
        // Inflate the layout for this fragment
        return settingsActivityBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Sets checkbox to if sms messaging is allowed
        settingsActivityBinding.allowTextCheckBox.setChecked(settingListener.checkSMSAllowed());

        // sets text to current string saved in the phone number variable
        settingsActivityBinding.editTextPhoneNumber.setText(settingListener.getPhoneNumber());

        // Ends fragment without saving anything if the cancel button is clicked
        settingsActivityBinding.settingsCancel.setOnClickListener(v -> settingListener.settingsCancel());

        /*
        if the save settings is tapped then
            send the boolean for if the checkbox for allowing messaging is checked as variable
            send the string in the phone number edit box as variable
         */
        settingsActivityBinding.saveSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                settingListener.settingSave(settingsActivityBinding.allowTextCheckBox.isChecked(),
                        settingsActivityBinding.editTextPhoneNumber.getText().toString());
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    SettingListener settingListener;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        settingListener = (SettingListener) context;
    }
    public interface SettingListener{
        void settingsCancel();
        void settingSave(boolean allowSMS, String phoneNumber);
        boolean checkSMSAllowed();
        String getPhoneNumber();

    }
}
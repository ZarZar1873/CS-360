package com.zybooks.druryoption1inventoryapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class ItemDAO {
        private SQLiteDatabase db;

        public ItemDAO(SQLiteDatabase db) {
                this.db = db;
        }

        public long create(Item item){
                ContentValues values = new ContentValues();

                values.put(ItemTable.COLUMN_NAME, item.getName());
                values.put(ItemTable.COLUMN_QUANTITY, item.getQuantity());

                return db.insert(ItemTable.TABLE_NAME, null, values);
        }

        public boolean update (Item item, String name, int quantity){
                ContentValues values = new ContentValues();
                item.setName(name);
                item.setQuantity(quantity);
                Log.d("test", "update: " + item.getName() + " " + item.getQuantity());

                values.put(ItemTable.COLUMN_NAME, item.getName());
                values.put(ItemTable.COLUMN_QUANTITY, item.getQuantity());

                return db.update(ItemTable.TABLE_NAME, values, ItemTable.COLUMN_ID + " = ?",
                        new String[]{String.valueOf(item.get_id())}) > 0;
        }

        public boolean update (Item item){
                ContentValues values = new ContentValues();

                values.put(ItemTable.COLUMN_NAME, item.getName());
                values.put(ItemTable.COLUMN_QUANTITY, item.getQuantity());

                return db.update(ItemTable.TABLE_NAME, values, ItemTable.COLUMN_ID + " = ?",
                        new String[]{String.valueOf(item.get_id())}) > 0;
        }

        public boolean delete (Item item){
                return db.delete(ItemTable.TABLE_NAME, ItemTable.COLUMN_ID + " = ?",
                        new String[]{String.valueOf(item.get_id())}) > 0;
        }

        public boolean delete (long id){
                return db.delete(ItemTable.TABLE_NAME, ItemTable.COLUMN_ID + " = ?",
                        new String[]{String.valueOf(id)}) > 0;
        }

        public Item get(long id){
                Item item = null;

                Cursor cursor = db.query(ItemTable.TABLE_NAME, new String[]{ItemTable.COLUMN_ID,
                                ItemTable.COLUMN_NAME, ItemTable.COLUMN_QUANTITY},
                        ItemTable.COLUMN_ID + " = ?", new String[]{String.valueOf(id)},
                        null, null, null);

                // Returns true if cursor was able to be moved
                if (cursor.moveToFirst()){
                        item = buildItemFromCursor(cursor);
                }

                return item;
        }

        public Item get(String name){
                Item item = null;

                Cursor cursor = db.query(ItemTable.TABLE_NAME, new String[]{ItemTable.COLUMN_ID,
                                ItemTable.COLUMN_NAME, ItemTable.COLUMN_QUANTITY},
                        ItemTable.COLUMN_NAME + " = ?", new String[]{name},
                        null, null, null);

                // Returns true if cursor was able to be moved
                if (cursor.moveToFirst()){
                        item = buildItemFromCursor(cursor);
                }

                return item;
        }

        public ArrayList<Item> getAll(){
                ArrayList<Item> items = new ArrayList<>();
                Item item;

                Cursor cursor = db.query(ItemTable.TABLE_NAME, new String[]{ItemTable.COLUMN_ID,
                                ItemTable.COLUMN_NAME, ItemTable.COLUMN_QUANTITY},
                        null, null, null, null, null);

                if(cursor.moveToFirst()) {
                        item = buildItemFromCursor(cursor);
                        items.add(item);
                }

                // Will return false if the cursor is already past the last entry in the result set
                while (cursor.moveToNext()){
                        item = buildItemFromCursor(cursor);
                        items.add(item);
                }

                return items;
        }

        private Item buildItemFromCursor (Cursor cursor){
                Item item = new Item();
                item.set_id(cursor.getLong(0));
                item.setName(cursor.getString(1));
                item.setQuantity(Integer.parseInt(cursor.getString(2)));
                return item;
        }
        }

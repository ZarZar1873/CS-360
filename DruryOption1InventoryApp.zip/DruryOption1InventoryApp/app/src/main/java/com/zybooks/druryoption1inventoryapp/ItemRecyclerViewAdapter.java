package com.zybooks.druryoption1inventoryapp;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Locale;

public class ItemRecyclerViewAdapter extends RecyclerView.Adapter<ItemRecyclerViewAdapter.
        ItemViewHolder>{
    ArrayList<Item> items; // Arraylist for storing items to be displayed
    InterfaceItemRecycler itemListener;

    public ItemRecyclerViewAdapter(ArrayList<Item> data, InterfaceItemRecycler itemListener) {
        this.itemListener = itemListener;
        this.items = data;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_inventory_row,
                parent, false);

        return new ItemViewHolder(view, itemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = items.get(position);
        holder.itemName.setText(item.name);
        holder.itemQuantity.setText(String.format(Locale.getDefault(), "%d", item.quantity));
        holder.position = holder.getAdapterPosition();
        holder.item = item;
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder{
        TextView itemName;
        EditText itemQuantity;
        View rootView;
        int position;
        Item item;
        InterfaceItemRecycler itemListener; // listener for interface

        public ItemViewHolder(@NonNull View itemView, InterfaceItemRecycler itemListener) {
            super(itemView);
            this.itemListener = itemListener;
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            rootView = itemView;

            //Text watcher for when quantity of item changes
            TextWatcher textWatcher = new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    /*
                    if teh item is not null and the quantity is not empty, then update the item
                    quantity in the database and if the quantity is less than or equal to 0 then send
                    sms to user informing them
                     */
                    if (item != null && !(itemQuantity.getText().toString().equals(""))) {
                        itemListener.updateItemQuantity(item.name, Integer.parseInt(itemQuantity.getText().toString()));
                        if ((Integer.parseInt(itemQuantity.getText().toString())) <= 0){
                            itemListener.sendSMS(item.name);
                        }
                    }
                }
            };

            /*
            if the delete button is tapped, then delete the item from the database and reload the \
            recycler view
             */
            itemView.findViewById(R.id.delBtn).setOnClickListener(v -> itemListener.deleteItem(item.name));

            itemQuantity.addTextChangedListener(textWatcher);
        }

    }

    interface InterfaceItemRecycler{
        void deleteItem(String name);
        void updateItemQuantity(String name, int quantity);
        void sendSMS(String name);
    }
}

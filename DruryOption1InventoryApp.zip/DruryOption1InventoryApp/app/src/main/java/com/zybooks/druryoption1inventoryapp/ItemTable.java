package com.zybooks.druryoption1inventoryapp;

import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class ItemTable {
    static final String TABLE_NAME = "item";
    static final String COLUMN_ID = "_id";
    static final String COLUMN_NAME = "name";
    static final String COLUMN_QUANTITY = "quantity";

    static public void onCreate(SQLiteDatabase db){
        StringBuilder sb = new StringBuilder();

        /*
         * Create table item (_id integer primary key autoincrement,
         * name text not null, quantity text not null)
         */
        sb.append("CREATE TABLE " + ItemTable.TABLE_NAME + " (");
        sb.append(COLUMN_ID + " integer primary key autoincrement, ");
        sb.append(COLUMN_NAME + " text not null, ");
        sb.append(COLUMN_QUANTITY + " text not null);");

        try {
            db.execSQL(sb.toString());
        } catch (SQLException ex){
            ex.printStackTrace();
        }
    }

    static public void onUpdate(SQLiteDatabase db, int oldVersion, int newVersion){
        try {
            db.execSQL("DROP TABLE IF EXISTS " + ItemTable.TABLE_NAME);
        }
        catch (SQLException ex){
            ex.printStackTrace();
        }
    }
}
